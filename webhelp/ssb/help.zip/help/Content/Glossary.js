CMCXmlParser._FilePathToXmlStringMap.Add(
	'Glossary',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<html xmlns:MadCap=\"http://www.madcapsoftware.com/Schemas/MadCap.xsd\" MadCap:disableMasterStylesheet=\"true\" MadCap:tocPath=\"\" MadCap:medium=\"non-print\" MadCap:InPreviewMode=\"false\" MadCap:PreloadImages=\"false\" MadCap:RuntimeFileType=\"Glossary\" MadCap:TargetType=\"WebHelp\" lang=\"en-ca\" xml:lang=\"en-ca\" MadCap:PathToHelpSystem=\"../\" MadCap:HelpSystemFileName=\"_start.xml\">' +
	'    <head>' +
	'        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />' +
	'        <link href=\"SkinSupport/MadCap.css\" rel=\"stylesheet\" type=\"text/css\" />' +
	'        <title>Glossary</title>' +
	'        <link href=\"Resources/StyleSheets/WebHelp.css\" rel=\"stylesheet\" type=\"text/css\" />' +
	'        <script src=\"SkinSupport/MadCapAll.js\" type=\"text/javascript\">' +
	'        </script>' +
	'    </head>' +
	'    <body style=\"background-color: #fafafa;\">' +
	'        <div id=\"GlossaryBody\">' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_4192724178_0\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">XVC</a>' +
	'                    <a name=\"4192724178_anchor1\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_4192724178_0\" style=\"display: none;\">XML VPN Client</div>' +
	'            </div>' +
	'        </div>' +
	'        <p>&#160;</p>' +
	'        <script type=\"text/javascript\" src=\"SkinSupport/MadCapBodyEnd.js\">' +
	'        </script>' +
	'    </body>' +
	'</html>'
);
