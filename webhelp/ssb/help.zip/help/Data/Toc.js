CMCXmlParser._FilePathToXmlStringMap.Add(
	'Toc',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultToc Version=\"1\" DescendantCount=\"69\">' +
	'    <TocEntry Title=\"1: Getting Started\" StartChapter=\"true\" PageLayout=\"/Content/Resources/PageLayouts/Chapters.flpgl\" PageType=\"right\" PageNumberReset=\"reset\" PageNumberFormat=\"decimal\" PageNumber=\"1\" StartSection=\"false\" ReplaceMergeNode=\"false\" Link=\"/Content/Welcome.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"true\" DescendantCount=\"2\">' +
	'        <TocEntry Title=\"Overview\" Link=\"/Content/Overview.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"About This Help System\" Link=\"/Content/About_This_Help_System.htm\" conditions=\"Primary.Exclude_from_print\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"2: Using the SecureSpan XML VPN Client\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" Link=\"/Content/SecureSpan_XML_VPN_Client_Overview.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"43\">' +
	'        <TocEntry Title=\"Interface\" Link=\"/Content/Interface.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"General Workflow\" Link=\"/Content/General_Workflow.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Troubleshooting Mode\" Link=\"/Content/Troubleshooting_Mode.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Daemon Mode\" Link=\"/Content/SecureSpan_XML_VPN_Client_in_Daemon_Mode.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Service Mode\" Link=\"/Content/SecureSpan_XML_VPN_Client_in_Service_Mode.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Working with Gateway Accounts\" Link=\"/Content/About_SecureSpan_Gateway_Accounts.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"15\">' +
	'            <TocEntry Title=\"Managing Gateway Accounts\" Link=\"/Content/Managing_Gateway_Accounts.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"5\">' +
	'                <TocEntry Title=\"Editing a Gateway Account\" Link=\"/Content/Editing_a_Gateway_Account.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'                <TocEntry Title=\"Deleting a Gateway Account\" Link=\"/Content/Deleting_a_Gateway_Account.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'                <TocEntry Title=\"Changing the Gateway Password\" Link=\"/Content/Changing_the_Gateway_Password.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'                <TocEntry Title=\"Changing the Default Gateway Account\" Link=\"/Content/Changing_the_Default_Gateway_Account.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'                <TocEntry Title=\"Removing the Default Status for a Gateway Account\" Link=\"/Content/Removing_the_Default_Status_for_a_Gateway_Account.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            </TocEntry>' +
	'            <TocEntry Title=\"Trusted Gateway Accounts\" Link=\"/Content/Trusted_Gateway_Accounts.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"1\">' +
	'                <TocEntry Title=\"Creating a Trusted Gateway Account\" Link=\"/Content/Creating_a_Trusted_Gateway_Account.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            </TocEntry>' +
	'            <TocEntry Title=\"Federated Gateway Accounts\" Link=\"/Content/Federated_Gateway_Accounts.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"3\">' +
	'                <TocEntry Title=\"Creating Account Based on Trusted Gateway\" Link=\"/Content/Creating_a_Federated_Gateway_Account__Trusted_Gateway_.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'                <TocEntry Title=\"Creating Account Based on WS-Federation\" Link=\"/Content/Creating_a_Federated_Gateway_Account__WS-Federation_.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'                <TocEntry Title=\"Creating Account Based on WS-Trust\" Link=\"/Content/Creating_a_Federated_Gateway_Account__WS-Trust_.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            </TocEntry>' +
	'            <TocEntry Title=\"Defining Additional Properties for Client Policy\" Link=\"/Content/Defining_Additional_Properties_for_Client_Policy.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Configuring SAML Sender Vouches\" Link=\"/Content/Configuring_SAML_Sender_Vouches.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Configuring WS-Federation Credential Exchange\" Link=\"/Content/Configuring_WS-Federation_Credential_Exchange.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Generic Web Services\" Link=\"/Content/Generic_Web_Services.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"1\">' +
	'            <TocEntry Title=\"Connecting to a Generic Web Service\" Link=\"/Content/Connecting_to_a_Generic_Web_Service.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Working with Policies\" Link=\"/Content/Policies_and_the_XML_VPN_Client.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"6\">' +
	'            <TocEntry Title=\"About Stored Policies\" Link=\"/Content/About_Stored_Policies.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Managing Stored Policies\" Link=\"/Content/Manage_Stored_Policies.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"4\">' +
	'                <TocEntry Title=\"Locking or Unlocking a Stored Policy\" Link=\"/Content/Locking_or_Unlocking_a_Stored_Policy.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'                <TocEntry Title=\"Setting the Policy Match Type\" Link=\"/Content/Setting_the_Policy_Match_Type.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'                <TocEntry Title=\"Configuring the Policy Attachment Key\" Link=\"/Content/Configuring_the_Policy_Resolution.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'                <TocEntry Title=\"Deleting a Stored Policy\" Link=\"/Content/Deleting_a_Stored_Policy.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            </TocEntry>' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Importing a Policy\" Link=\"/Content/Importing_a_Policy.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Exporting a Policy\" Link=\"/Content/Exporting_a_Policy.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Configuring Message Routing\" Link=\"/Content/About_Message_Routing.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"3\">' +
	'            <TocEntry Title=\"Configuring Message Routing\" Link=\"/Content/Configure_Message_Routing.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Message Compression\" Link=\"/Content/Message_Compression.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Configuring Client Applications\" Link=\"/Content/Configure_Client_Applications.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Managing Security Sessions\" Link=\"/Content/Manage_Security_Sessions.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'            <TocEntry Title=\"About SSL/TLS Security Sessions\" Link=\"/Content/About_SSL_TLS_Security_Sessions.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Life Cycle of Security Sessions\" Link=\"/Content/Lifecycle_of_Security_Sessions.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Analyzing XML VPN Client Performance\" Link=\"/Content/Analyzing_SecureSpan_XML_VPN_Client_Performance.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'            <TocEntry Title=\"Viewing Message Traffic\" Link=\"/Content/Viewing_Message_Traffic.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Viewing the Log Files\" Link=\"/Content/Viewing_the_Log_Files.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Configuring Windows Domain Identity Injection\" Link=\"/Content/Configuring_Windows_Identity_Injection.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"3: Identity Bridging\" Link=\"/Content/Identity_Bridging.htm\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"12\">' +
	'        <TocEntry Title=\"Requirements\" Link=\"/Content/Identity_Bridging_Requirements.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"SAML Workflow\" Link=\"/Content/Workflow_Using_SAML.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"X.509 Certificate Workflow\" Link=\"/Content/Workflow_Using_an_X.509_Certificate.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Managing Certificates\" Link=\"/Content/Managing_Certificates.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Managing Federated Identity Providers\" Link=\"/Content/Federated_Identity_Providers.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Managing FIP Users and Groups\" Link=\"/Content/Federated_Identity_Provider_Users_and_Groups.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Configuring SAML Policies for Identity Bridging\" Link=\"/Content/Configuring_SAML_Policies_for_Identity_Bridging.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Configuring Gateway Accounts for Identity Bridging\" Link=\"/Content/Configuring_Gateway_Accounts_for_Identity_Bridging.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"3\">' +
	'            <TocEntry Title=\"Configuring Gateway Accounts\" Link=\"/Content/Configure_SecureSpan_Gateway_Accounts.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Full Identity Bridging Method\" Link=\"/Content/Full_Identity_Bridging_Method.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Ad-hoc Identity Bridging Method\" Link=\"/Content/Ad-hoc_Identity_Bridging_Method.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Consuming Shared Web Services\" Link=\"/Content/Consume_Shared_Web_Service.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Appendixes\" ComputedFirstTopic=\"false\" DescendantCount=\"9\">' +
	'        <TocEntry Title=\"Appx A: Contacting Layer 7 Technologies\" Link=\"/Content/Contact_Information.htm\" StartSection=\"false\" StartChapter=\"true\" PageType=\"title\" PageNumber=\"1\" PageNumberReset=\"continue\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Appx B: System Properties\" Link=\"/Content/System_Properties.htm\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"5\">' +
	'            <TocEntry Title=\"Enabling Request/Response Message Logging\" Link=\"/Content/Enabling_Request_Response_Message_Logging.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Overriding the Logging Default Severity Level\" Link=\"/Content/Overriding_Logging_Default_Security_Level.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Overriding the HTTP Time-Out Period\" Link=\"/Content/Overriding_HTTP_Time-Out_Period.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Overriding Key Usage\" Link=\"/Content/Overriding_Key_Usage.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"1\">' +
	'                <TocEntry Title=\"Key Usage Enforcement Policy\" Link=\"/Content/Key_Usage_Enforcement_Policy.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            </TocEntry>' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Appx C: Policy Authentication Hierarchy\" Link=\"/Content/Policy_Authentication_Hierarchy.htm\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Appx D: Using the WSIL Viewer\" Link=\"/Content/Using_the_WSIL_Viewer.htm\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'</CatapultToc>'
);
