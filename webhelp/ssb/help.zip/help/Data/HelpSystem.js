var xmlHelpSystemData = "";
xmlHelpSystemData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlHelpSystemData += '<WebHelpSystem DefaultUrl=\"Content/Welcome.htm\" Toc=\"Data/Toc.xml\" Index=\"Data/Index.xml\" Concepts=\"Data/Concepts.xml\" Glossary=\"Content/Glossary.htm\" SearchDatabase=\"Data/Search.xml\" Alias=\"Data/Alias.xml\" Synonyms=\"Data/Synonyms.xml\" Skin=\"Data/Skinriver/Skin.xml\" Skins=\"river\" BuildTime=\"8/13/2014 11:55:54 AM\" BuildVersion=\"10.2.0.0\" TargetType=\"WebHelp\" SkinTemplateFolder=\"Skin/\" InPreviewMode=\"false\" MoveOutputContentToRoot=\"false\" MakeFileLowerCase=\"false\" UseCustomTopicFileExtension=\"false\" />';
CMCXmlParser._FilePathToXmlStringMap.Add('HelpSystem', xmlHelpSystemData);
