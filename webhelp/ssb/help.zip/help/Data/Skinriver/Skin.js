CMCXmlParser._FilePathToXmlStringMap.Add(
	'Skin',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultSkin Version=\"1\" Title=\"SecureSpan XML VPN Client Help System\" Top=\"50px\" Left=\"50px\" Width=\"800px\" Height=\"660px\" Tabs=\"TOC,Index,Search,Favorites\" AutoSyncTOC=\"True\" Bottom=\"314px\" Right=\"430px\" UseDefaultBrowserSetup=\"true\" BrowserSetup=\"\" UseBrowserDefaultSize=\"true\">' +
	'    <!-- saved from url=(0014)about:internet -->' +
	'    <Toc LinesBetweenItems=\"False\" LinesFromRoot=\"False\" SingleClick=\"False\" PlusMinusSquares=\"False\" AlwaysShowSelection=\"False\" UseFolderIcons=\"False\" ImageListWidth=\"\" BinaryStorage=\"False\" />' +
	'    <WebHelpOptions VisibleAccordionItemCount=\"3\" NavigationPaneWidth=\"250\" HideNavigationOnStartup=\"False\" NavigationPanePosition=\"Left\" />' +
	'    <Stylesheet Link=\"Stylesheet.xml\">' +
	'    </Stylesheet>' +
	'    <Toolbar EnableCustomLayout=\"true\" Buttons=\"Back|Forward|Stop|Refresh|Print|AddTopicToFavorites|Home\" />' +
	'</CatapultSkin>'
);
