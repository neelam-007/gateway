CMCXmlParser._FilePathToXmlStringMap.Add(
	'Search_Chunk21',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?><index><stem n=\"8765\"><phr n=\"8765\"><ent r=\"7\" t=\"45\" w=\"157\" /></phr></stem><stem n=\"(start/stop).\"><phr n=\"(start/stop).\"><ent r=\"7\" t=\"45\" w=\"179\" /></phr></stem><stem n=\"(applianc\"><phr n=\"(Appliance\"><ent r=\"8\" t=\"45\" w=\"205\" /></phr></stem></index>'
);
