CMCXmlParser._FilePathToXmlStringMap.Add(
	'Toc',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultToc Version=\"1\" DescendantCount=\"47\">' +
	'    <TocEntry Title=\"1: Getting Started\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"reset\" StartSection=\"false\" VolumeNumberReset=\"same\" SectionNumberReset=\"continue\" ChapterNumberReset=\"continue\" ComputeToc=\"false\" ReplaceMergeNode=\"false\" FrameName=\"\" PageNumberFormat=\"decimal\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"6\">' +
	'        <TocEntry Title=\"Welcome to the Enterprise Service Manager\" Link=\"/Content/ESM_User_Guide/Welcome_to_Enterprise_Service_Manager.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"true\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Starting the Enterprise Service Manager Web Interface\" Link=\"/Content/ESM_User_Guide/Starting_Enterprise_Service_Manager.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Interface Overview\" Link=\"/Content/ESM_User_Guide/Interface_Overview.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Organizing Clusters and Nodes\" Link=\"/Content/ESM_User_Guide/Using_the_Enterprise_Tree.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Viewing Audits and Logs\" Link=\"/Content/ESM_User_Guide/Viewing_Audits_and_Logs.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Enabling/Disabling the Enterprise Service Manager\" Link=\"/Content/ESM_User_Guide/Enabling_or_Disabling_the_Enterprise_Service_Manager.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"2: Configuring Enterprise Service Manager\" Link=\"\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ReplaceMergeNode=\"false\" FrameName=\"\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"4\">' +
	'        <TocEntry Title=\"Overview of Configuration Process\" Link=\"/Content/ESM_User_Guide/Overview_of_Configuration_Process.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Setting Up Enterprise Service Manager\" Link=\"/Content/ESM_User_Guide/Setting_Up_Enterprise_Service_Manager.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Installing the Enterprise Service Manager License\" Link=\"/Content/ESM_User_Guide/Installing_the_ESM_License.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Enable Remote Management on Nodes\" Link=\"/Content/ESM_User_Guide/Enabling_Remote_Management_on_Nodes.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"3: Working with Clusters\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"5\">' +
	'        <TocEntry Title=\"Organizing Clusters and Nodes\" Link=\"/Content/ESM_User_Guide/Organizing_Clusters_and_Nodes.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Adding a Gateway Cluster to Manage\" Link=\"/Content/ESM_User_Guide/Adding_a_Gateway_Cluster_to_Manage.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Establishing Trust with a Cluster\" Link=\"/Content/ESM_User_Guide/Establishing_Trust_with_a_Cluster.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Mapping an ESM&#160;User to a Cluster User Account\" Link=\"/Content/ESM_User_Guide/Mapping_an_ESM_User_to_a_Cluster.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Removing Trust Relationship with a Cluster\" Link=\"/Content/ESM_User_Guide/Removing_Trust_Relatonship_with_a_Cluster.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"4: Configuring Monitoring\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'        <TocEntry Title=\"Configuring Monitored Properties\" Link=\"/Content/ESM_User_Guide/Configuring_Monitored_Properties.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Creating Notification Rules for Monitoring\" Link=\"/Content/ESM_User_Guide/Creating_Notification_Rules_for_Monitoring.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"5: Migrating Services and Policies\" Link=\"\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'        <TocEntry Title=\"Migrating a Service or Policy\" Link=\"/Content/ESM_User_Guide/Migrating_a_Service_or_Policy.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Viewing Migration History\" Link=\"/Content/ESM_User_Guide/Viewing_Migration_History.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"6: Working with Users\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"7\">' +
	'        <TocEntry Title=\"Creating a New User Account\" Link=\"/Content/ESM_User_Guide/Creating_a_New_User_Account.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Editing a User Account\" Link=\"/Content/ESM_User_Guide/Editing_a_User_Account.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Deleting a User Account\" Link=\"/Content/ESM_User_Guide/Deleting_a_User_Account.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Managing User Roles\" Link=\"/Content/ESM_User_Guide/Managing_User_Roles.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Adding a User to a Role\" Link=\"/Content/ESM_User_Guide/Adding_a_User_to_a_Role.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Removing a User from a Role\" Link=\"/Content/ESM_User_Guide/Removing_a_User_from_a_Role.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Resetting a Password\" Link=\"/Content/ESM_User_Guide/Resetting_a_Password.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"7: Generating Reports\" Link=\"/Content/ESM_User_Guide/Generating_Reports.htm\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"3\">' +
	'        <TocEntry Title=\"Grouping by Message Context Key\" Link=\"/Content/ESM_User_Guide/Grouping_by_Message_Context_Key.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Managing Reports\" Link=\"/Content/ESM_User_Guide/Managing_Reports.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Explanation of Report Columns\" Link=\"/Content/ESM_User_Guide/Explanation_of_Report_Columns.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Enterprise Service Manager: Reference\" StartChapter=\"true\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"false\" DescendantCount=\"15\">' +
	'        <TocEntry Title=\"Manage Gateways Tab\" Link=\"/Content/ESM_User_Guide/Manage_Gateways_Tab.htm\" StartChapter=\"false\" PageType=\"right\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'            <TocEntry Title=\"Monitor Page\" Link=\"/Content/ESM_User_Guide/Monitor_Page.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Configure Page\" Link=\"/Content/ESM_User_Guide/Configure_Page.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Manage Policies Tab\" Link=\"/Content/ESM_User_Guide/Manage_Policies_Tab.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'            <TocEntry Title=\"Migration Page\" Link=\"/Content/ESM_User_Guide/Migration_Page.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"History Page\" Link=\"/Content/ESM_User_Guide/History_Page.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Reports Tab\" Link=\"/Content/ESM_User_Guide/Reports_Tab.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\">' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Tools Tab\" Link=\"/Content/ESM_User_Guide/Tools_Tab.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'            <TocEntry Title=\"Audits Page\" Link=\"/Content/ESM_User_Guide/Audits_Page.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Logs Page\" Link=\"/Content/ESM_User_Guide/Logs_Page.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Settings Tab\" Link=\"/Content/ESM_User_Guide/Settings_Tab.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"4\">' +
	'            <TocEntry Title=\"User Settings Page\" Link=\"/Content/ESM_User_Guide/User_Settings_Page.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"System Settings Page\" Link=\"/Content/ESM_User_Guide/System_Settings_Page.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"User Accounts Page\" Link=\"/Content/ESM_User_Guide/User_Accounts_Page.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"User Roles Page\" Link=\"/Content/ESM_User_Guide/User_Roles_Page.htm\" StartChapter=\"false\" PageNumber=\"1\" PageNumberReset=\"continue\" StartSection=\"false\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Appendix A: Ports Used by the Enterprise Service Manager\" Link=\"/Content/ESM_User_Guide/Ports_Used_by_the_ESM.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    <TocEntry Title=\"Appendix B: Configuring the ESM Logs\" Link=\"/Content/ESM_User_Guide/Configuring_the_ESM_Logs.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'</CatapultToc>'
);
