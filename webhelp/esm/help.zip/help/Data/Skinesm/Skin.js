CMCXmlParser._FilePathToXmlStringMap.Add(
	'Skin',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultSkin Version=\"1\" Comment=\"Blue theme skin\" Anchors=\"Width,Height\" Width=\"800px\" Height=\"600px\" Top=\"0px\" Left=\"0px\" Bottom=\"0px\" Right=\"0px\" Tabs=\"TOC,Index,Search\" DefaultTab=\"TOC\" UseBrowserDefaultSize=\"True\" UseDefaultBrowserSetup=\"True\" AutoSyncTOC=\"true\" Title=\"Enterprise Service Manager Online Help\">' +
	'    <!-- saved from url=(0014)about:internet -->' +
	'    <Index BinaryStorage=\"True\" />' +
	'    <HtmlHelpOptions ShowMenuBar=\"False\" TopmostWindowStyle=\"False\" Buttons=\"Hide,Locate,Back,Forward,Stop,Refresh,Home,Font,Print\" EnableButtonCaptions=\"True\" />' +
	'    <Stylesheet Link=\"Stylesheet.xml\">' +
	'    </Stylesheet>' +
	'    <Toolbar EnableCustomLayout=\"true\" Buttons=\"Back|Forward|Print|Refresh|AddTopicToFavorites|Separator|QuickSearch|RemoveHighlight\" ExcludeAccordionTitle=\"true\" />' +
	'</CatapultSkin>'
);
