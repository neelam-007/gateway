CMCXmlParser._FilePathToXmlStringMap.Add(
	'Index',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?><CatapultTargetIndex Count=\"155\" Char_65=\"0\" Char_67=\"5\" Char_68=\"19\" Char_69=\"25\" Char_70=\"42\" Char_71=\"45\" Char_72=\"49\" Char_73=\"53\" Char_76=\"55\" Char_77=\"61\" Char_78=\"78\" Char_79=\"86\" Char_80=\"89\" Char_82=\"99\" Char_83=\"114\" Char_84=\"134\" Char_85=\"139\" Char_86=\"151\" Char_87=\"154\"><Chunks><Chunk FirstTerm=\"Adding a Gateway Cluster to Manage\" Link=\"Index_Chunk1.xml\" Start=\"0\" Count=\"93\" /><Chunk FirstTerm=\"Policy\" Link=\"Index_Chunk2.xml\" Start=\"93\" Count=\"62\" /></Chunks><IndexEntry><Entries></Entries><Links /><SeeAlsoLinks /><IndexControlLinks /></IndexEntry></CatapultTargetIndex>'
);
