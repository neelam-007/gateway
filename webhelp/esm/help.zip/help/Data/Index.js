CMCXmlParser._FilePathToXmlStringMap.Add(
	'Index',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?><CatapultTargetIndex Count=\"148\" Char_65=\"0\" Char_67=\"5\" Char_68=\"18\" Char_69=\"22\" Char_70=\"39\" Char_71=\"42\" Char_72=\"46\" Char_73=\"50\" Char_76=\"52\" Char_77=\"56\" Char_78=\"73\" Char_79=\"81\" Char_80=\"84\" Char_82=\"93\" Char_83=\"108\" Char_84=\"128\" Char_85=\"133\" Char_86=\"145\" Char_87=\"147\"><Chunks><Chunk FirstTerm=\"Adding a Gateway Cluster to Manage\" Link=\"Index_Chunk1.xml\" Start=\"0\" Count=\"93\" /><Chunk FirstTerm=\"Remote management\" Link=\"Index_Chunk2.xml\" Start=\"93\" Count=\"55\" /></Chunks><IndexEntry><Entries></Entries><Links /><SeeAlsoLinks /><IndexControlLinks /></IndexEntry></CatapultTargetIndex>'
);
