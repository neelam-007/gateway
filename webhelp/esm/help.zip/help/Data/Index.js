CMCXmlParser._FilePathToXmlStringMap.Add(
	'Index',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?><CatapultTargetIndex Count=\"152\" Char_65=\"0\" Char_67=\"5\" Char_68=\"19\" Char_69=\"24\" Char_70=\"41\" Char_71=\"44\" Char_72=\"48\" Char_73=\"52\" Char_76=\"54\" Char_77=\"59\" Char_78=\"76\" Char_79=\"84\" Char_80=\"87\" Char_82=\"97\" Char_83=\"112\" Char_84=\"132\" Char_85=\"137\" Char_86=\"149\" Char_87=\"151\"><Chunks><Chunk FirstTerm=\"Adding a Gateway Cluster to Manage\" Link=\"Index_Chunk1.xml\" Start=\"0\" Count=\"94\" /><Chunk FirstTerm=\"Ports Use by the ESM\" Link=\"Index_Chunk2.xml\" Start=\"94\" Count=\"58\" /></Chunks><IndexEntry><Entries></Entries><Links /><SeeAlsoLinks /><IndexControlLinks /></IndexEntry></CatapultTargetIndex>'
);
