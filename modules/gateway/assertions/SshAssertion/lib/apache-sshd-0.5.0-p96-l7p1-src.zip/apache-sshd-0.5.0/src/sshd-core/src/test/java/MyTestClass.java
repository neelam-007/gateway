import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.security.KeyPair;

public class MyTestClass {
    public static void main(String[] args) {
        try {
            // Deserialize from a file
            File file = new File("C:\\WS01\\trunk\\key.ser");
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
            // Deserialize the object
            KeyPair keySer = (KeyPair) in.readObject();
            in.close();
        } catch (ClassNotFoundException e) {
            // do nothing
        } catch (IOException e) {
            // do nothing
        }
    }
}
